import { createClient } from '@supabase/supabase-js';
import crypto from 'node:crypto';

export const supabase = createClient(
  process.env.SUPABASE_URL || '',
  process.env.SUPABASE_SERVICE_ROLE_KEY || '',
  { auth: { persistSession: false, autoRefreshToken: false } }
);

export function json(res, status, body) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  return res.status(status).json(body);
}
export function readBody(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  return {};
}
export function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
export function makeToken() {
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + 8 * 60 * 60 * 1000 })).toString('base64url');
  const sig = crypto.createHmac('sha256', process.env.ADMIN_TOKEN_SECRET || '').update(payload).digest('base64url');
  return payload + '.' + sig;
}
export function isAdmin(req) {
  const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const [payload, sig] = token.split('.');
  if (!payload || !sig || !process.env.ADMIN_TOKEN_SECRET) return false;
  const expected = crypto.createHmac('sha256', process.env.ADMIN_TOKEN_SECRET).update(payload).digest('base64url');
  if (!safeEqual(sig, expected)) return false;
  try { return JSON.parse(Buffer.from(payload, 'base64url').toString()).exp > Date.now(); }
  catch { return false; }
}
export function requireAdmin(req, res) {
  if (!isAdmin(req)) { json(res, 401, { error: 'Login admin diperlukan.' }); return false; }
  return true;
}
