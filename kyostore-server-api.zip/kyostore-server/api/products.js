import { supabase, json, readBody, requireAdmin } from './_lib.js';
export default async function handler(req, res) {
  if (req.method === 'GET') {
    const { data, error } = await supabase.from('products').select('id,name,category,price,icon,description,active,created_at').eq('active', true).order('created_at', { ascending: false });
    if (error) return json(res, 500, { error: 'Gagal mengambil produk.' });
    return json(res, 200, { products: data || [] });
  }
  if (!['POST','PATCH','DELETE'].includes(req.method)) return json(res, 405, { error: 'Method tidak diizinkan.' });
  if (!requireAdmin(req,res)) return;
  const b = readBody(req);
  if (req.method === 'POST' || req.method === 'PATCH') {
    const item = { name: String(b.name||'').trim(), category: String(b.category||'Umum').trim(), price: Number(b.price||0), icon: String(b.icon||'✦').trim(), description: String(b.description||'').trim(), active: b.active !== false };
    if (item.name.length < 2 || item.description.length < 3 || !Number.isFinite(item.price) || item.price < 0)
      return json(res, 400, { error: 'Data produk tidak valid.' });
    let query;
    if (req.method === 'POST') query = supabase.from('products').insert(item).select().single();
    else {
      if (!b.id) return json(res, 400, { error: 'ID produk wajib diisi.' });
      query = supabase.from('products').update(item).eq('id', b.id).select().single();
    }
    const { data, error } = await query;
    if (error) return json(res, 500, { error: 'Gagal menyimpan produk.' });
    return json(res, 200, { product: data });
  }
  if (!b.id) return json(res, 400, { error: 'ID produk wajib diisi.' });
  const { error } = await supabase.from('products').update({ active: false }).eq('id', b.id);
  if (error) return json(res, 500, { error: 'Gagal menonaktifkan produk.' });
  return json(res, 200, { ok: true });
}