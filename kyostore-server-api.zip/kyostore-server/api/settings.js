import { supabase, json, readBody, requireAdmin } from './_lib.js';
export default async function handler(req,res) {
 if(req.method==='GET'){
  const {data,error}=await supabase.from('store_settings').select('key,value');
  if(error)return json(res,500,{error:'Gagal mengambil pengaturan.'});
  const settings=Object.fromEntries((data||[]).map(x=>[x.key,x.value]));
  return json(res,200,{settings});
 }
 if(req.method==='PUT'){
  if(!requireAdmin(req,res))return;
  const b=readBody(req);
  const allowed=['name','logo','whatsapp','accent_color','payment_instructions'];
  const rows=allowed.filter(k=>b[k]!==undefined).map(key=>({key,value:String(b[key]).slice(0,2000)}));
  if(!rows.length)return json(res,400,{error:'Tidak ada pengaturan untuk disimpan.'});
  const {error}=await supabase.from('store_settings').upsert(rows,{onConflict:'key'});
  if(error)return json(res,500,{error:'Gagal menyimpan pengaturan.'});
  return json(res,200,{ok:true});
 }
 return json(res,405,{error:'Method tidak diizinkan.'});
}