import { supabase, json, readBody, requireAdmin } from './_lib.js';
function clean(s, n=1500) { return String(s ?? '').trim().slice(0,n); }
export default async function handler(req, res) {
  if (req.method === 'POST') {
    const b = readBody(req);
    const name=clean(b.name,80), phone=clean(b.phone,24), details=clean(b.details,1500), productId=Number(b.productId);
    if(name.length<2 || !/^\+?[0-9 ()-]{9,22}$/.test(phone) || details.length<8 || !Number.isInteger(productId))
      return json(res,400,{error:'Nama, nomor WhatsApp, layanan, atau detail kebutuhan tidak valid.'});
    const { data: p, error: pe } = await supabase.from('products').select('id,name,price').eq('id',productId).eq('active',true).single();
    if(pe || !p) return json(res,404,{error:'Layanan tidak ditemukan.'});
    const { data, error } = await supabase.from('orders').insert({
      product_id:p.id, product_name:p.name, customer_name:name, phone:phone,
      details, price:p.price, status:'Menunggu pembayaran', payment_status:'Belum dibayar'
    }).select('id,product_name,customer_name,price,status,payment_status,created_at').single();
    if(error) return json(res,500,{error:'Pesanan belum berhasil disimpan. Coba lagi.'});
    return json(res,201,{order:data});
  }
  if (req.method === 'GET') {
    if (!requireAdmin(req,res)) return;
    const { data, error } = await supabase.from('orders').select('*').order('created_at',{ascending:false});
    if(error) return json(res,500,{error:'Gagal mengambil pesanan.'});
    return json(res,200,{orders:data||[]});
  }
  if (req.method === 'PATCH') {
    if (!requireAdmin(req,res)) return;
    const b=readBody(req);
    const allowed=['Menunggu pembayaran','Menunggu verifikasi','Dibayar','Diproses','Menunggu revisi','Selesai','Dibatalkan'];
    if(!b.id || !allowed.includes(b.status)) return json(res,400,{error:'Status pesanan tidak valid.'});
    const patch={status:b.status};
    if(b.payment_status) {
      if(!['Belum dibayar','Menunggu verifikasi','Dibayar','Ditolak'].includes(b.payment_status))
        return json(res,400,{error:'Status pembayaran tidak valid.'});
      patch.payment_status=b.payment_status;
    }
    const {data,error}=await supabase.from('orders').update(patch).eq('id',b.id).select().single();
    if(error) return json(res,500,{error:'Gagal memperbarui pesanan.'});
    return json(res,200,{order:data});
  }
  if (req.method === 'DELETE') {
    if (!requireAdmin(req,res)) return;
    const b=readBody(req);
    if(!b.id) return json(res,400,{error:'ID pesanan wajib diisi.'});
    const {error}=await supabase.from('orders').delete().eq('id',b.id);
    if(error) return json(res,500,{error:'Gagal menghapus pesanan.'});
    return json(res,200,{ok:true});
  }
  return json(res,405,{error:'Method tidak diizinkan.'});
}