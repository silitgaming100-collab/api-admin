import { json, readBody, safeEqual, makeToken } from './_lib.js';
export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { error: 'Method tidak diizinkan.' });
  const { username, password } = readBody(req);
  if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD || !process.env.ADMIN_TOKEN_SECRET)
    return json(res, 500, { error: 'Konfigurasi admin belum lengkap di Vercel.' });
  if (!safeEqual(username, process.env.ADMIN_USERNAME) || !safeEqual(password, process.env.ADMIN_PASSWORD))
    return json(res, 401, { error: 'Username atau password salah.' });
  return json(res, 200, { token: makeToken(), expiresIn: 28800 });
}