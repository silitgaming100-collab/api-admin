# KyoStore Server API (Vercel + Supabase)

Paket ini menambahkan API dan database bersama agar pesanan dari pelanggan bisa terlihat di dashboard admin dari perangkat lain. Ini backend/API, bukan dashboard frontend yang sudah otomatis tersambung; frontend KyoStore juga perlu diubah agar memakai endpoint `/api/...`.

## 1. Buat database Supabase
1. Buat project di https://supabase.com/
2. Buka SQL Editor.
3. Salin dan jalankan semua isi `supabase-schema.sql`.
4. Dari Project Settings > API, catat Project URL dan `service_role` key. **Jangan pernah taruh service role key di HTML, GitHub publik, atau chat.**

## 2. Upload project ke Vercel
1. Ekstrak ZIP ini, lalu masukkan file/folder ke project GitHub yang digunakan Vercel (atau deploy sebagai project baru).
2. Di Vercel > Project > Settings > Environment Variables, tambahkan:
   - `SUPABASE_URL` = URL project Supabase
   - `SUPABASE_SERVICE_ROLE_KEY` = service_role key (rahasia)
   - `ADMIN_USERNAME` = username admin pilihan
   - `ADMIN_PASSWORD` = password unik yang kuat
   - `ADMIN_TOKEN_SECRET` = string acak panjang, minimal 32 karakter
3. Redeploy setelah menambahkan environment variables.

## 3. Endpoint yang tersedia
- `POST /api/login` — login admin, mengembalikan token berlaku 8 jam.
- `GET /api/products` — daftar produk aktif.
- `POST /api/products` — tambah produk (butuh `Authorization: Bearer TOKEN`).
- `PATCH /api/products` — edit produk.
- `DELETE /api/products` — nonaktifkan produk.
- `POST /api/orders` — buat pesanan dari website.
- `GET /api/orders` — daftar pesanan admin.
- `PATCH /api/orders` — ubah status pesanan/pembayaran.
- `DELETE /api/orders` — hapus pesanan.
- `GET /api/settings` — pengaturan toko.
- `PUT /api/settings` — ubah pengaturan (admin).

## Penting sebelum dipakai pelanggan
- Kode frontend lama masih menggunakan `localStorage`. Kalau hanya menambahkan folder `api`, checkout frontend lama belum otomatis mengirim pesanan ke database. Frontend harus diintegrasikan ke endpoint ini.
- Uji semua alur di preview/deployment sebelum dipakai sungguhan.
- Simpan backup dan jangan membagikan `service_role` key.
